## Overview

This plugin shows how to insert content or another document in current documents.


It is called "Example insert content & document" in the interface and isn't installed by default in cloud, [self-hosted](https://github.com/ONLYOFFICE/DocumentServer) and [desktop version](https://github.com/ONLYOFFICE/DesktopEditors) of ONLYOFFICE editors. 

## How to use

1. Open the Plugins tab and press "Example insert content & document" (all content will be added at the current cursor position).

If you need more information about how to use or write your own plugin, please see this https://api.onlyoffice.com/plugin/basic