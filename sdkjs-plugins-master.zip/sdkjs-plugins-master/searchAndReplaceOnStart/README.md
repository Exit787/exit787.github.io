## Overview

This plugin shows how to search and replace in document on start.

It is without interface plugin and isn't installed by default in cloud, [self-hosted](https://github.com/ONLYOFFICE/DocumentServer) and [desktop version](https://github.com/ONLYOFFICE/DesktopEditors) of ONLYOFFICE editors. 

## How to use

1. Enter any text into document (for this example is "ONLYOFFICE").
2. In plugin code in "replaceString" field enter text to replace.
3. Reopen a document.

If you need more information about how to use or write your own plugin, please see this https://api.onlyoffice.com/plugin/basic