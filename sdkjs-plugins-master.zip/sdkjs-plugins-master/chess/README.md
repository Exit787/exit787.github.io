## Overview

This plugin shows how to work with OLE-objects and save data to your document.

It is called Chess in the interface and isn't installed by default in cloud, [self-hosted](https://github.com/ONLYOFFICE/DocumentServer) and [desktop version](https://github.com/ONLYOFFICE/DesktopEditors) of ONLYOFFICE editors. 

## How to use

1. Open the Plugins tab and press Chess.

If you need more information about how to use or write your own plugin, please see this https://api.onlyoffice.com/plugin/basic