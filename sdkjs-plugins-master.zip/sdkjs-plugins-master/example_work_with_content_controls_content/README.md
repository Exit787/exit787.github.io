## Overview

This plugin show how to insert the contents of one content control into another.

It is called "Example work with content controls content" in the interface and isn't installed by default in cloud, [self-hosted](https://github.com/ONLYOFFICE/DocumentServer) and [desktop version](https://github.com/ONLYOFFICE/DesktopEditors) of ONLYOFFICE editors. 

## How to use

1. Add two content control (1 - with tag 11, 2 - with tag 14).
2. Open the Plugins tab and press "Example work with content controls content" (content from content control with tag 11 will be inserted into content control with tag 14).

If you need more information about how to use or write your own plugin, please see this https://api.onlyoffice.com/plugin/basic