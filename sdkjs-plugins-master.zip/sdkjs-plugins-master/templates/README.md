## Overview

This plugin shows how to set document templates.

It is called "Document Templates" in the interface and isn't installed by default in cloud, [self-hosted](https://github.com/ONLYOFFICE/DocumentServer) and [desktop version](https://github.com/ONLYOFFICE/DesktopEditors) of ONLYOFFICE editors. 

## How to use

1. Find the plugin in the Plugins tab.
2. Сhoose any style you want to set.

If you need more information about how to use or write your own plugin, please see this https://api.onlyoffice.com/plugin/basic