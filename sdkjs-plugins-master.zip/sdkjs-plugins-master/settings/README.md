## Overview

This plugin shows how to protect a document using a watermark.

It is without interface plugin and isn't installed by default in cloud, [self-hosted](https://github.com/ONLYOFFICE/DocumentServer) and [desktop version](https://github.com/ONLYOFFICE/DesktopEditors) of ONLYOFFICE editors. 

## How to use

1. In plugin code in "initSettings" field the document settings.
3. Reopen a document.

If you need more information about how to use or write your own plugin, please see this https://api.onlyoffice.com/plugin/basic